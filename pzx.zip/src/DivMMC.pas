{ DivMMC: the DivMMC interface. 8K of EEPROM (the firmware, e.g. ESXDOS),
  128K of RAM in 16 banks of 8K, an SD card on SPI and automatic paging.

  Ports (low byte decoded):
    E3  control (write): bit 7 CONMEM (map now, EEPROM at 0000), bit 6
        MAPRAM (bank 3 replaces the EEPROM, read-only; can't be cleared
        until power off), bits 0-3 the RAM bank at 2000-3FFF
    E7  card select (write): bit 0 low selects the card
    EB  SPI data (read and write)

  When mapped, 0000-1FFF holds the EEPROM (or RAM bank 3 with MAPRAM) and
  2000-3FFF the selected RAM bank. Mapping happens automatically on opcode
  fetches: at once at 3D00-3DFF, and after the fetch at 0000, 0008, 0038,
  0066, 04C6 and 0562; unmapping after a fetch at 1FF8-1FFF. }
unit DivMMC;

{$mode objfpc}{$H+}
{$R-}{$Q-}

interface

uses
  SysUtils, Classes, SDCard;

const
  DIVMMC_BANKS = 16;

type
  TDivMMC = class
  private
    FRom: array[0..$1FFF] of Byte;
    FRam: array[0..DIVMMC_BANKS - 1, 0..$1FFF] of Byte;
    FControl: Byte;
    FMapped: Boolean;
    FCard: TSDCard;
    FRomLoaded: Boolean;
    function GetActive: Boolean; inline;
  public
    constructor Create;
    destructor Destroy; override;
    { The firmware (an 8K EEPROM image) }
    procedure LoadRom(const FileName: string);
    { Power on (Hard) or reset: unmapped; MAPRAM survives a reset }
    procedure Reset(Hard: Boolean);
    { Memory at Addr (0000-3FFF) while Active }
    function Read(Addr: Word): Byte; inline;
    procedure Write(Addr: Word; Value: Byte);
    { Automatic paging around an opcode fetch at Addr }
    procedure BeforeFetch(Addr: Word); inline;
    procedure AfterFetch(Addr: Word); inline;
    { Ports E3, E7, EB }
    function IsPort(Port: Word): Boolean; inline;
    function ReadPort(Port: Word): Byte;
    procedure WritePort(Port: Word; Value: Byte);
    { SD card: an image file, or none }
    procedure InsertCard(const FileName: string);
    procedure EjectCard;
    property Card: TSDCard read FCard;
    { Mapped in now (automatically or with CONMEM) }
    property Active: Boolean read GetActive;
    property Control: Byte read FControl;
    { Debugger: change the control register (MAPRAM still can't be cleared)
      and the automatic paging state }
    procedure SetControl(Value: Byte);
    property Mapped: Boolean read FMapped write FMapped;
    property RomLoaded: Boolean read FRomLoaded;
  end;

implementation

constructor TDivMMC.Create;
begin
  inherited Create;
  FillChar(FRom, SizeOf(FRom), $FF);
  Reset(True);
end;

destructor TDivMMC.Destroy;
begin
  FCard.Free;
  inherited Destroy;
end;

procedure TDivMMC.LoadRom(const FileName: string);
var
  S: TFileStream;
begin
  S := TFileStream.Create(FileName, fmOpenRead or fmShareDenyWrite);
  try
    FillChar(FRom, SizeOf(FRom), $FF);
    S.Read(FRom, SizeOf(FRom));
  finally
    S.Free;
  end;
  FRomLoaded := True;
end;

procedure TDivMMC.Reset(Hard: Boolean);
begin
  if Hard then
  begin
    FControl := 0;
    FillChar(FRam, SizeOf(FRam), 0);
  end
  else
    FControl := FControl and $40;
  FMapped := False;
end;

function TDivMMC.GetActive: Boolean;
begin
  Result := FMapped or ((FControl and $80) <> 0);
end;

function TDivMMC.Read(Addr: Word): Byte;
begin
  if Addr < $2000 then
  begin
    if ((FControl and $80) = 0) and ((FControl and $40) <> 0) then
      Result := FRam[3, Addr]
    else
      Result := FRom[Addr];
  end
  else
    Result := FRam[FControl and $0F, Addr and $1FFF];
end;

procedure TDivMMC.Write(Addr: Word; Value: Byte);
var
  Bank: Integer;
begin
  // 0000-1FFF is the EEPROM (write-protected) or the read-only bank 3
  if Addr < $2000 then Exit;
  Bank := FControl and $0F;
  if ((FControl and $C0) = $40) and (Bank = 3) then Exit;   // MAPRAM: bank 3 is read-only
  FRam[Bank, Addr and $1FFF] := Value;
end;

procedure TDivMMC.BeforeFetch(Addr: Word);
begin
  // ROM 3Dxx (the TR-DOS entry points): mapped before the opcode is read
  if (Addr and $FF00) = $3D00 then FMapped := True;
end;

procedure TDivMMC.AfterFetch(Addr: Word);
begin
  case Addr of
    $0000, $0008, $0038, $0066, $04C6, $0562: FMapped := True;
    $1FF8..$1FFF: FMapped := False;
  end;
end;

procedure TDivMMC.SetControl(Value: Byte);
begin
  FControl := Value or (FControl and $40);
end;

function TDivMMC.IsPort(Port: Word): Boolean;
begin
  Result := ((Port and $FF) = $E3) or ((Port and $FF) = $E7) or ((Port and $FF) = $EB);
end;

function TDivMMC.ReadPort(Port: Word): Byte;
begin
  if ((Port and $FF) = $EB) and (FCard <> nil) then
    Result := FCard.ReadByte
  else
    Result := $FF;
end;

procedure TDivMMC.WritePort(Port: Word; Value: Byte);
begin
  case Port and $FF of
    $E3: FControl := Value or (FControl and $40);   // MAPRAM can't be cleared
    $E7: if FCard <> nil then FCard.Select((Value and 1) = 0);
    $EB: if FCard <> nil then FCard.WriteByte(Value);
  end;
end;

procedure TDivMMC.InsertCard(const FileName: string);
var
  NewCard: TSDCard;
begin
  NewCard := TSDCard.Create(FileName);   // raises if it can't be opened
  FCard.Free;
  FCard := NewCard;
end;

procedure TDivMMC.EjectCard;
begin
  FreeAndNil(FCard);
end;

end.
